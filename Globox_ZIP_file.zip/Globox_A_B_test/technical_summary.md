# A/B Test Report: Food and Drink Banner

## Purpose
Company wants to bring awareness to this product category to increase revenue.

## Hypotheses
What are the null and alternative hypotheses we are testing?
H0: p1 = p2 (The conversion rates in the control and treatment groups are equal) 
HA: p1 ≠ p2 (The conversion rates in the control and treatment groups are not equal)
Hypothesis test for Conversion rate
In other words, we are testing to see if is in there a statistically significant difference between Control and Treatment group. Google Spreadsheet and Excel was used to complete these calculations. Significance level for identification of the power of our evidence is 0.05.
H0: p1 = p2 (The conversion rates in the control and treatment groups are equal) 
HA: p1 ≠ p2 (The conversion rates in the control and treatment groups are not equal)
Control group = A
Treatment group = B      
Test: Two Sample Z test
Distribution: Normal Distribution
Sample Size: A = 24343, B = 24,600
Conversion rate: A = 0.03923099, B = 0.046300813
Pooled proportion: (0.03923099 * 24343 + 0.046300813 * 24600) / (24343+ 24600) = 0.042784464
Standard Error: √(0.042784464 * (1-0.042784464) * (1 / 24343 + 1 / 24600) = 0.001829526
Test Statistic: (0.03923099 - 0.046300813) / 0.001829526 = 3.86429177
P-Value: 2 * (1 – NORM.S.DIST(3.86429177, TRUE)) = 0.000111

P-Value 0.001829526 is less than significance level 0.05 and that’s why we rejected Null Hypothesis. There’s a statistically significant difference in conversion rate between two groups.

95% Confidence Interval for Conversion Rate  
The 95% Confidence interval for the difference between two groups [0.0035, 0.01065].
Control group = A
Treatment group = B      
Critical Value:  NORM.S.INV(1-(aplha/2) = 1.959963985
Standard Error: √(0.042784464 * (1-0.042784464) * ((1/24343) + (1/24600)))
Margin of Error: 1.959963985 * 0.001829526 = 0.003585805
Lower Bound: (0.046300813 - 0.03923099) - 0.003585805=0.003484017
Upper Bound: (0.046300813 - 0.03923099) + 0.003585805=0.010655628
Point Estimate: 0.010655628 - 0.003484017 = 0.00717161

Hypothesis test average amount per user
Hypothesis test was conducted to identify a difference in average amount per user between two groups. Spreadsheet and Excel was used for this test.
H0: μ1 = μ2 (The average amount spent per user in the control and treatment groups is equal) HA: μ1 ≠ μ2 (The average amount spent per user in the control and treatment groups is not equal)
Control group = A
Treatment group = B      
Test: Two sample Z test
Distribution: Normal distribution
Significance level: 0.05
Sample means (avg spent): X-bar A = 3.374518468, X-bar B = 3.390866946
Sample Standard Deviation: A = 25.93639056, B = 25.4141096
Sample size: A = 24343 , B = 24600
Degrees of Freedom: MIN((24343-1), (24600-1)) = 24342
Standard Error: SQRT((25.4141096)^2/ 24600+( 25.93639056)^2/ 24343) = 0.232140559
Test Statistic: ((3.390866946- 3.374518468)-0)/ 0.232140559 = 0.07042491

P-Value: 0.943856044 is more than 0.05 significance level and that’s why we fail to reject null hypothesis. There’s a statistically insignificant difference in conversion rate between two groups

95% Confidential Interval in average amount between two group

The 95% Confidence interval for the difference between two groups [-0.4386, 0.4713].
Control group = A
Treatment group = B      
Test: Two sample Z test
Distribution: Normal Distribution
Significance level: 0.05
Sample means: x- bar A = 3.374518468, x-bar B = 3.390866946
Sample Standard Deviation: A = 25.93639056, B = 25.4141096
Sample size: A = 24343 , B = 24600
Degrees of Freedom: MIN((24343-1), (24600-1))= 24342
Critical Value: TINV(0.05, 24342) = 1.960061445
Standard Error: SQRT((25.4141096)^2/ 24600+( 25.93639056)^2/ 24343)= 0.232140559
Margin of Error: (1.960061445* 0.232140559) = 0.455009759
Lower Bound: (3.390866946- 3.374518468) - 0.455009759 = -0.438661281
Upper Bound: (3.390866946- 3.374518468) + 0.455009759 = 0.471358237
Point Estimate: 0.471358237 - 0.438661281 = 0.032696956

## Methodology
Conversion rate
Average amount spent
Exploratory analysis
Power analysis
Novelty effect
### Test Design
- **Population:** Control A = 24343, Treatment B = 24,600
- **Duration:** January 25 and February 6
- **Success Metrics:** Conversion rate and average amount per user

## Results
Hypothesis test for Conversion rate
In other words, we are testing to see if is in there a statistically significant difference between Control and Treatment group. Google Spreadsheet and Excel was used to complete these calculations. Significance level for identification of the power of our evidence is 0.05.
H0: p1 = p2 (The conversion rates in the control and treatment groups are equal) 
HA: p1 ≠ p2 (The conversion rates in the control and treatment groups are not equal)
Control group = A
Treatment group = B      
Test: Two Sample Z test
Distribution: Normal Distribution
Sample Size: A = 24343, B = 24,600
Conversion rate: A = 0.03923099, B = 0.046300813
Pooled proportion: (0.03923099 * 24343 + 0.046300813 * 24600) / (24343+ 24600) = 0.042784464
Standard Error: √(0.042784464 * (1-0.042784464) * (1 / 24343 + 1 / 24600) = 0.001829526
Test Statistic: (0.03923099 - 0.046300813) / 0.001829526 = 3.86429177
P-Value: 2 * (1 – NORM.S.DIST(3.86429177, TRUE)) = 0.000111

P-Value 0.001829526 is less than significance level 0.05 and that’s why we rejected Null Hypothesis. There’s a statistically significant difference in conversion rate between two groups.

95% Confidence Interval for Conversion Rate  
The 95% Confidence interval for the difference between two groups [0.0035, 0.01065].
Control group = A
Treatment group = B      
Critical Value:  NORM.S.INV(1-(aplha/2) = 1.959963985
Standard Error: √(0.042784464 * (1-0.042784464) * ((1/24343) + (1/24600)))
Margin of Error: 1.959963985 * 0.001829526 = 0.003585805
Lower Bound: (0.046300813 - 0.03923099) - 0.003585805=0.003484017
Upper Bound: (0.046300813 - 0.03923099) + 0.003585805=0.010655628
Point Estimate: 0.010655628 - 0.003484017 = 0.00717161



Hypothesis test average amount per user
Hypothesis test was conducted to identify a difference in average amount per user between two groups. Spreadsheet and Excel was used for this test.
H0: μ1 = μ2 (The average amount spent per user in the control and treatment groups is equal) HA: μ1 ≠ μ2 (The average amount spent per user in the control and treatment groups is not equal)
Control group = A
Treatment group = B      
Test: Two sample Z test
Distribution: Normal distribution
Significance level: 0.05
Sample means (avg spent): X-bar A = 3.374518468, X-bar B = 3.390866946
Sample Standard Deviation: A = 25.93639056, B = 25.4141096
Sample size: A = 24343 , B = 24600
Degrees of Freedom: MIN((24343-1), (24600-1)) = 24342
Standard Error: SQRT((25.4141096)^2/ 24600+( 25.93639056)^2/ 24343) = 0.232140559
Test Statistic: ((3.390866946- 3.374518468)-0)/ 0.232140559 = 0.07042491

P-Value: 0.943856044 is more than 0.05 significance level and that’s why we fail to reject null hypothesis. There’s a statistically insignificant difference in conversion rate between two groups

95% Confidential Interval in average amount between two group

The 95% Confidence interval for the difference between two groups [0.0035, 0.01065].
Control group = A
Treatment group = B      
Test: Two sample Z test
Distribution: Normal Distribution
Significance level: 0.05
Sample means: x- bar A = 3.374518468, x-bar B = 3.390866946
Sample Standard Deviation: A = 25.93639056, B = 25.4141096
Sample size: A = 24343 , B = 24600
Degrees of Freedom: MIN((24343-1), (24600-1))= 24342
Critical Value: TINV(0.05, 24342) = 1.960061445
Standard Error: SQRT((25.4141096)^2/ 24600+( 25.93639056)^2/ 24343)= 0.232140559
Margin of Error: (1.960061445* 0.232140559) = 0.455009759
Lower Bound: (3.390866946- 3.374518468) - 0.455009759 = -0.438661281
Upper Bound: (3.390866946- 3.374518468) + 0.455009759 = 0.471358237
Point Estimate: 0.471358237 - 0.438661281 = 0.032696956

### Data Analysis
- **Pre-Processing Steps:** Include any SQL queries and describe data cleaning steps.

```sql
1.Can a user show up more than once in the activity table? Yes or no, and why?
Yes, same customer can make many purchases in activity table.
select 
count(distinct uid)
from activity
Select 
count(uid)
from activity

2.What type of join should we use to join the users table to the activity table?
Left join 
Select 
count(distinct u.id)
From users u
Left join activity a on u.id=a.uid

3.What SQL function can we use to fill in NULL values?
Coalesce

4.What are the start and end dates of the experiment?
start date
"2023-01-25"
select
min(join_dt)
from groups
end date
"2023-02-06"
select
max(join_dt)
from groups

5.How many total users were in the experiment?
"48943"
select 
count(users)
from users

6.How many users were in the control and treatment groups?
select
groups.device,
count(*) 
from groups
group by 1

7.What was the conversion rate of all users?
SELECT Count(*) AS user_counter, conversion
FROM (SELECT u.id,
 u.country,
 u.gender,
 g.group,
 g.device,
 CASE
 WHEN a.spent > 0 THEN 'True'
 ELSE 'False'
 END AS Conversion,
 Sum(a.spent) AS total_spent
 FROM users u
 LEFT JOIN groups g
 ON g.uid = u.id
 LEFT JOIN activity a
 ON a.uid = g.uid
 GROUP BY 1, 2, 3, 4, 5,
6) t1
GROUP BY 2



8.What is the user conversion rate for the control and treatment groups?
with t1 as (
select 
u.id,
u.country,
u.gender,
a.device,
Coalesce(g.group, 'N/A') as group,
Case when coalesce(a.spent, 0) > 0 Then 'Converted' ELSE 'Not Converted'
END as Conversion,
sum(a.spent) total_spent
from users u
left join activity a on u.id = a.uid 
left join groups g on a.uid = g.uid
group by 
1, 2,3,4,5,6)
select
count(*) as user_count,
t1.group,
conversion
from t1
where t1.conversion = 'Converted'
group by 2,3

SQL extract to Tableu
WITH t1
 AS (SELECT u.id,
 u.country,
 u.gender,
 g.group,
 g.device,
 CASE
 WHEN COALESCE(a.spent, 0) > 0 THEN 'True'
 ELSE 'False'
 END AS Conversion,
 Sum(a.spent) AS total_spent
 FROM users u
 LEFT JOIN groups g
 ON g.uid = u.id
 LEFT JOIN activity a
 ON a.uid = g.uid
 GROUP BY 1,
 2, 3, 4, 5, 6)
SELECT id,
 COALESCE(country, 'N/A') country,
 COALESCE(gender, 'N/A') gender,
 t1.group,
 COALESCE (device, 'N/A') device,
 conversion,
 COALESCE (total_spent, 0) total_spent
FROM t1
ORDER BY 4

SQL query for Novelty Test
SELECT u.id as user_id, coalesce(cast(a.dt as varchar), 'N/A') as date, g.group, g.join_dt as join_date,
    CASE WHEN a.spent > 0 THEN 'True'
    ELSE 'False' END as Conversion,
    SUM(coalesce(a.spent, 0)) as total_spent
FROM users u

LEFT JOIN groups g on g.uid = u.id
LEFT JOIN activity a on a.uid = g.uid
GROUP BY
    u.id, a.spent, g.group, g.join_dt, a.dt

Python code for Power analysis
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.stats.power import TTestIndPower, NormalIndPower
csv_path = '/Globox A B test CSV.csv'
globox=pd.read_csv(csv_path)
globox.info()
globox.head()
# Segregating the data into control and test groups
control_group = globox[globox['group'] == 'A']
treatment_group = globox[globox['group'] == 'B']
# Calculating the baseline metrics for the control group
control_conv_rate = control_group['conversion'].mean()
control_avg_amount_spent = control_group['total_spent'].mean()
# Calculating the metrics for the test group
treatment_conversion_rate = treatment_group['conversion'].mean()
treatment_avg_amount_spent = treatment_group['total_spent'].mean()

# Preparing a summary of the metrics
metrics_summary = pd.DataFrame({
    "Metric": ["Conversion Rate", "Average Amount Spent"],
    "Group A: Control": [control_conv_rate, control_avg_amount_spent],
    "Group B: Test": [treatment_conversion_rate, treatment_avg_amount_spent]})
metrics_summary.set_index("Metric", inplace=True)
metrics_summary
# Parameters for the power analysis
alpha = 0.05  # Significance level
power = 0.80  # Statistical power
mde_relative = 0.10  # Minimum Detectable Effect (10% relative change)
conversion = 1
# Calculating the absolute MDE for conversion rate and average amount spent
mde_conversion_rate = control_conv_rate * mde_relative
mde_avg_amount_spent = control_avg_amount_spent * mde_relative
# Power analysis for conversion rate (two-sample proportion test)
effect_size_conversion_rate = NormalIndPower().solve_power(
    effect_size=(mde_conversion_rate / np.sqrt(control_conv_rate * (1 - control_conv_rate))),
    alpha=alpha,
    power=power,
    ratio=1  # Equal size for control and test groups)
# Power analysis for average amount spent (two-sample t-test)
effect_size_avg_amount_spent = TTestIndPower().solve_power(
    effect_size=(mde_avg_amount_spent / control_group['total_spent'].std()),
    alpha=alpha,
    power=power,
    ratio=1,  # Equal size for control and test groups
    alternative='two-sided')
required_sample_size = pd.DataFrame({
    "Metric": ["Conversion Rate", "Average Amount Spent"],
    "Required Sample Size": [effect_size_conversion_rate, effect_size_avg_amount_spent]})
required_sample_size.set_index("Metric", inplace=True)
required_sample_size

```

- **Statistical Tests Used:** Two sample Z test.
- **Results Overview:** High-level summary.

### Findings
There is a significant difference in conversion rate between Treatment and Control grops. 
There is no significant difference in average amount per user.
## Interpretation
- **Outcome of the Test(s):** We reject null hypothesis in conversion rate. We fail to reject null hypothesis in average amount spent.
- **Confidence Level:** The 95% Confidence interval in conversion rate for the difference between two groups [0.0035, 0.01065]
The 95% Confidence interval in average amount spent for the difference between two groups [-0.4386, 0.4713]
## Conclusions
- **Key Takeaways:** Positive: Treatment group has higher conversion rate than Control. Negative: No significant difference in average amount spent. 
- **Limitations/Considerations:** Less number of users for a better test.

## Recommendations
- **Next Steps:** Don't launch for all users.
- **Further Analysis:** Get more number of users, conduct competitors analysis, Conversion rate is not that important if your revenue is not high. 

