# resource links

google sheets link (if applicable):
python notebook link (if applicable):https://colab.research.google.com/drive/1Q7gS-wM1Bwgo1wGfNA2vN_7btLqq_ztA#scrollTo=g8AECDyjnYbH
tableau public link:https://public.tableau.com/app/profile/azat.beisheev/viz/Tableuanalysis/Conversionrateandaverageamountspentbetweenthetestgroups?publish=yes
presentation video link:https:https://www.loom.com/share/b1609c6938524dc6a19ae57d908b4600?sid=935c770b-0e28-4e7d-9bfb-3f77dc783c84